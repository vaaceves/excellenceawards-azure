from django.apps import AppConfig


class AwardsConfig(AppConfig):
    name = 'awards'
